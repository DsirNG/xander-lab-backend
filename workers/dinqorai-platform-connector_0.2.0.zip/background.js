import {
  API_BASE_URL,
  CONNECTOR_ORIGINS,
  PLATFORM_COOKIE_DOMAINS,
  PLATFORM_URLS,
  SESSION_COOKIE_NAMES,
} from "./config.js";

const TASKS_KEY = "authorizationTasks";
const inFlightTasks = new Set();
const SUPPORTED_PLATFORMS = Object.keys(PLATFORM_URLS);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "PING") {
    sendResponse({ available: true });
    return false;
  }
  if (message?.type === "CANCEL") {
    const pageUrl = sender.url ? new URL(sender.url) : null;
    if (pageUrl && CONNECTOR_ORIGINS.has(pageUrl.origin) && /^[0-9a-f-]{36}$/i.test(message.taskId)) {
      readTasks().then((tasks) => {
        const task = tasks.find((entry) => entry.taskId === message.taskId);
        if (task) return removeTask(task, true);
      });
    }
    return false;
  }
  if (message?.type !== "START") return false;

  const pageUrl = sender.url ? new URL(sender.url) : null;
  if (!pageUrl || !CONNECTOR_ORIGINS.has(pageUrl.origin)
    || !SUPPORTED_PLATFORMS.includes(message.platform)
    || !/^[0-9a-f-]{36}$/i.test(message.taskId)
    || !/^[A-Za-z0-9_-]{43}$/.test(message.transferToken)) {
    sendResponse({ ok: false });
    return false;
  }

  beginAuthorization(message).then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
  return true;
});

chrome.cookies.onChanged.addListener(({ cookie, removed }) => {
  if (removed) return;
  const platform = platformForCookie(cookie);
  if (platform && SESSION_COOKIE_NAMES[platform].includes(cookie.name)) {
    void checkPlatformTasks(platform);
  }
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "authorization-check") void checkPlatformTasks();
});

async function beginAuthorization(task) {
  const active = await readTasks();
  const previous = active.filter((entry) => entry.platform === task.platform);
  for (const entry of previous) await removeTask(entry, true);

  const tab = await chrome.tabs.create({ url: PLATFORM_URLS[task.platform], active: true });
  active.push({ ...task, tabId: tab.id, expiresAt: Date.now() + 5 * 60_000 });
  await chrome.storage.local.set({ [TASKS_KEY]: active });
  chrome.alarms.create("authorization-check", { periodInMinutes: 0.5 });
  void checkPlatformTasks(task.platform).catch(() => {});
}

async function checkPlatformTasks(platformFilter) {
  const tasks = await readTasks();
  for (const task of tasks) {
    if (platformFilter && task.platform !== platformFilter) continue;
    if (inFlightTasks.has(task.taskId)) continue;
    if (task.expiresAt <= Date.now()) {
      await removeTask(task, true);
      continue;
    }
    inFlightTasks.add(task.taskId);
    try {
      const cookies = await chrome.cookies.getAll({ url: PLATFORM_URLS[task.platform] });
      const values = new Map(cookies.map((cookie) => [cookie.name, cookie.value]));
      const sessionKey = SESSION_COOKIE_NAMES[task.platform].some((name) => values.has(name));
      if (!sessionKey) continue;

      const cookie = cookies
        .filter((entry) => entry.name && !/[\r\n;=]/.test(entry.name) && !/[\r\n;]/.test(entry.value))
        .sort((left, right) => left.name.localeCompare(right.name))
        .map((entry) => `${entry.name}=${entry.value}`)
        .join("; ");
      const accountName = task.platform === "csdn" ? values.get("UserName") || null : null;
      const credential = task.platform === "csdn"
        ? { cookie, username: accountName || "" }
        : task.platform === "juejin"
          ? {
          cookie,
          csrfToken: values.get("passport_csrf_token") || "",
          uuid: values.get("uuid") || "",
          sessionKey: values.get("sessionid_ss") || values.get("sessionid") || values.get("sid_tt") || "",
        }
          : { cookie };

      const response = await fetch(
        `${API_BASE_URL}/api/publishing/${task.platform}/authorization/extension/${task.taskId}/complete`,
        {
          method: "POST",
          headers: {
            "content-type": "application/json",
            authorization: `Bearer ${task.transferToken}`,
          },
          body: JSON.stringify({ credential, accountName }),
          cache: "no-store",
        },
      );
      if (response.ok || response.status === 409 || response.status === 410) await removeTask(task, true);
    } catch {
      // Cookie and transfer tokens stay out of extension logs; the next alarm retries transient network errors.
    } finally {
      inFlightTasks.delete(task.taskId);
    }
  }
}

async function removeTask(task, closeTab) {
  const remaining = (await readTasks()).filter((entry) => entry.taskId !== task.taskId);
  await chrome.storage.local.set({ [TASKS_KEY]: remaining });
  if (closeTab && Number.isInteger(task.tabId)) {
    try { await chrome.tabs.remove(task.tabId); } catch { /* tab may already be closed */ }
  }
  if (remaining.length === 0) await chrome.alarms.clear("authorization-check");
}

async function readTasks() {
  const stored = await chrome.storage.local.get(TASKS_KEY);
  return Array.isArray(stored[TASKS_KEY]) ? stored[TASKS_KEY] : [];
}

function platformForCookie(cookie) {
  const domain = cookie.domain.replace(/^\./, "");
  for (const [platform, domains] of Object.entries(PLATFORM_COOKIE_DOMAINS)) {
    if (domains.some((allowed) => domain === allowed || domain.endsWith(`.${allowed}`))) return platform;
  }
  return null;
}
