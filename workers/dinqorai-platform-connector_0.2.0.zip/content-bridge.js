(() => {
  const channel = "dinqorai-platform-connector";
  const supportedPlatforms = [
    "csdn", "juejin", "wechat_mp", "weibo", "zhihu", "baijiahao", "cnblogs",
    "douyin", "xiaohongshu", "toutiao", "51cto", "jianshu", "segmentfault",
    "oschina", "bilibili", "tencent_dev", "aliyun_dev",
  ];
  const allowedOrigins = new Set([
    "https://dinqor.cn",
    "https://xiaod.dpdns.org",
    "http://localhost:5173",
    "http://localhost:3000",
  ]);

  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== window.location.origin
      || !allowedOrigins.has(event.origin) || event.data?.channel !== channel) return;

    const message = event.data;
    if (message.type === "PING") {
      chrome.runtime.sendMessage({ type: "PING" }, (reply) => {
        window.postMessage({ channel, type: "PONG", requestId: message.requestId, available: Boolean(reply?.available) }, event.origin);
      });
      return;
    }
    if (message.type === "CANCEL" && typeof message.taskId === "string") {
      chrome.runtime.sendMessage({ type: "CANCEL", taskId: message.taskId });
      return;
    }
    if (message.type !== "START" || typeof message.requestId !== "string"
      || !supportedPlatforms.includes(message.platform)
      || typeof message.taskId !== "string" || typeof message.transferToken !== "string") return;

    chrome.runtime.sendMessage({
      type: "START",
      platform: message.platform,
      taskId: message.taskId,
      transferToken: message.transferToken,
    }, (reply) => {
      const runtimeError = chrome.runtime.lastError;
      window.postMessage({
        channel,
        type: "START_RESULT",
        requestId: message.requestId,
        ok: !runtimeError && Boolean(reply?.ok),
      }, event.origin);
    });
  });
})();
