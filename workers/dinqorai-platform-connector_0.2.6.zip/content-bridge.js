(() => {
  const channel = "dinqorai-platform-connector";
  const taskIdPattern = /^[0-9a-f-]{36}$/i;
  const supportedPlatforms = [
    "csdn", "juejin", "wechat_mp", "weibo", "zhihu", "baijiahao", "cnblogs",
    "douyin", "xiaohongshu", "toutiao", "51cto", "jianshu", "segmentfault",
    "oschina", "bilibili", "tencent_dev", "aliyun_dev",
  ];
  const allowedOrigins = new Set([
    "https://dinqor.cn",
    "https://xiaod.dpdns.org",
    "http://localhost:5173",
    "http://localhost:3000",
  ]);

  function sendRuntimeMessage(message, onReply) {
    let settled = false;
    const finish = (reply, failed) => {
      if (settled) return;
      settled = true;
      onReply?.(reply, failed);
    };

    try {
      if (!chrome.runtime?.id) {
        finish(null, true);
        return;
      }
      chrome.runtime.sendMessage(message, (reply) => {
        try {
          finish(reply, Boolean(chrome.runtime.lastError));
        } catch {
          finish(null, true);
        }
      });
    } catch {
      finish(null, true);
    }
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type !== "AUTHORIZATION_PROGRESS" || !taskIdPattern.test(message.taskId)
      || !["WAITING_FOR_SESSION", "SUBMITTING", "RETRYING", "COMPLETED", "FAILED"].includes(message.state)) return false;

    window.postMessage({
      channel,
      type: "AUTHORIZATION_PROGRESS",
      taskId: message.taskId,
      state: message.state,
      errorCode: typeof message.errorCode === "string" ? message.errorCode : null,
    }, window.location.origin);
    return false;
  });

  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== window.location.origin
      || !allowedOrigins.has(event.origin) || event.data?.channel !== channel) return;

    const message = event.data;
    if (message.type === "PING") {
      sendRuntimeMessage({ type: "PING" }, (reply, failed) => {
        window.postMessage({ channel, type: "PONG", requestId: message.requestId, available: !failed && Boolean(reply?.available) }, event.origin);
      });
      return;
    }
    if (message.type === "CANCEL" && typeof message.taskId === "string") {
      sendRuntimeMessage({ type: "CANCEL", taskId: message.taskId });
      return;
    }
    if (message.type !== "START" || typeof message.requestId !== "string"
      || !supportedPlatforms.includes(message.platform)
      || typeof message.taskId !== "string" || typeof message.transferToken !== "string") return;

    sendRuntimeMessage({
      type: "START",
      platform: message.platform,
      taskId: message.taskId,
      transferToken: message.transferToken,
    }, (reply, failed) => {
      window.postMessage({
        channel,
        type: "START_RESULT",
        requestId: message.requestId,
        ok: !failed && Boolean(reply?.ok),
      }, event.origin);
    });
  });
})();
