import {
  API_BASE_URL,
  CONNECTOR_ORIGINS,
  PLATFORM_COOKIE_DOMAINS,
  PLATFORM_URLS,
  SESSION_COOKIE_NAMES,
} from "./config.js";

const TASKS_KEY = "authorizationTasks";
const inFlightTasks = new Set();
const SUPPORTED_PLATFORMS = Object.keys(PLATFORM_URLS);

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "PING") {
    sendResponse({ available: true });
    return false;
  }
  if (message?.type === "CANCEL") {
    const pageUrl = sender.url ? new URL(sender.url) : null;
    if (pageUrl && CONNECTOR_ORIGINS.has(pageUrl.origin) && /^[0-9a-f-]{36}$/i.test(message.taskId)) {
      readTasks().then((tasks) => {
        const task = tasks.find((entry) => entry.taskId === message.taskId);
        if (task) return removeTask(task, true);
      });
    }
    return false;
  }
  if (message?.type !== "START") return false;

  const pageUrl = sender.url ? new URL(sender.url) : null;
  if (!pageUrl || !CONNECTOR_ORIGINS.has(pageUrl.origin)
    || !Number.isInteger(sender.tab?.id)
    || !SUPPORTED_PLATFORMS.includes(message.platform)
    || !/^[0-9a-f-]{36}$/i.test(message.taskId)
    || !/^[A-Za-z0-9_-]{43}$/.test(message.transferToken)) {
    sendResponse({ ok: false });
    return false;
  }

  beginAuthorization(message, sender.tab.id).then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
  return true;
});

chrome.cookies.onChanged.addListener(({ cookie, removed }) => {
  if (removed) return;
  const platform = platformForCookie(cookie);
  if (platform && SESSION_COOKIE_NAMES[platform].includes(cookie.name)) {
    void checkPlatformTasks(platform);
  }
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "authorization-check") void checkPlatformTasks();
});

async function beginAuthorization(task, connectorTabId) {
  const active = await readTasks();
  const previous = active.filter((entry) => entry.platform === task.platform);
  for (const entry of previous) await removeTask(entry, true);

  const tab = await chrome.tabs.create({ url: PLATFORM_URLS[task.platform], active: true });
  const authorizationTask = {
    ...task,
    tabId: tab.id,
    connectorTabId,
    expiresAt: Date.now() + 5 * 60_000,
  };
  active.push(authorizationTask);
  await chrome.storage.local.set({ [TASKS_KEY]: active });
  chrome.alarms.create("authorization-check", { periodInMinutes: 0.5 });
  notifyConnector(authorizationTask, "WAITING_FOR_SESSION");
  void checkPlatformTasks(task.platform).catch(() => {});
}

async function checkPlatformTasks(platformFilter) {
  const tasks = await readTasks();
  for (const task of tasks) {
    if (platformFilter && task.platform !== platformFilter) continue;
    if (inFlightTasks.has(task.taskId)) continue;
    if (task.expiresAt <= Date.now()) {
      notifyConnector(task, "FAILED", "TASK_EXPIRED");
      await removeTask(task, true);
      continue;
    }
    inFlightTasks.add(task.taskId);
    try {
      const platformOrigin = new URL(PLATFORM_URLS[task.platform]).origin;
      const hasPlatformPermission = await chrome.permissions.contains({ origins: [`${platformOrigin}/*`] });
      if (!hasPlatformPermission) {
        logAuthorization(task.platform, "permission-check", "SITE_PERMISSION_REQUIRED");
        notifyConnector(task, "FAILED", "SITE_PERMISSION_REQUIRED");
        await removeTask(task, false);
        continue;
      }

      // CSDN identity cookies may belong to a different subdomain from the publishing cookies.
      // Endpoint scopes supply publishing cookies; the domain fallback queries identity names only.
      const csdnSession = task.platform === "csdn" ? await getCsdnCookies() : null;
      const cookies = csdnSession?.cookies
        ?? await chrome.cookies.getAll({ url: PLATFORM_URLS[task.platform] });
      const values = new Map(cookies.map((cookie) => [cookie.name, cookie.value]));
      const hasSession = SESSION_COOKIE_NAMES[task.platform].some((name) => Boolean(values.get(name)));
      if (!hasSession) {
        const errorCode = task.platform === "csdn" ? "SESSION_COOKIE_MISSING" : null;
        const diagnostic = {
          sitePermissionGranted: true,
          sessionCookieFound: false,
          cookieCount: cookies.length,
        };
        logAuthorization(task.platform, "cookie-check", errorCode ?? "SESSION_COOKIE_MISSING", {
          ...diagnostic,
          cookieScopes: csdnSession?.queryCounts,
        });
        notifyConnector(task, "WAITING_FOR_SESSION", errorCode, diagnostic);
        continue;
      }
      logAuthorization(task.platform, "cookie-check", "SESSION_COOKIE_FOUND", {
        sitePermissionGranted: true,
        sessionCookieFound: true,
        cookieCount: cookies.length,
        cookieScopes: csdnSession?.queryCounts,
      });

      const cookie = cookies
        .filter((entry) => entry.name && !/[\r\n;=]/.test(entry.name) && !/[\r\n;]/.test(entry.value))
        .sort((left, right) => left.name.localeCompare(right.name))
        .map((entry) => `${entry.name}=${entry.value}`)
        .join("; ");
      const accountName = task.platform === "csdn"
        ? csdnSession.accountName || values.get("UserName") || null
        : null;
      const credential = task.platform === "csdn"
        ? { cookie, username: accountName || "" }
        : task.platform === "juejin"
          ? {
          cookie,
          csrfToken: values.get("passport_csrf_token") || "",
          uuid: values.get("uuid") || "",
          sessionKey: values.get("sessionid_ss") || values.get("sessionid") || values.get("sid_tt") || "",
        }
          : { cookie };

      notifyConnector(task, "SUBMITTING", null, { sessionCookieFound: true, cookieCount: cookies.length });
      let response;
      try {
        response = await fetch(
          `${API_BASE_URL}/api/publishing/${task.platform}/authorization/extension/${task.taskId}/complete`,
          {
            method: "POST",
            headers: {
              "content-type": "application/json",
              authorization: `Bearer ${task.transferToken}`,
            },
            body: JSON.stringify({ credential, accountName }),
            cache: "no-store",
          },
        );
      } catch {
        logAuthorization(task.platform, "complete", "NETWORK_ERROR");
        notifyConnector(task, "RETRYING", "NETWORK_ERROR");
        continue;
      }

      if (response.ok) {
        const result = await readCompletionResult(response);
        logAuthorization(task.platform, "complete", "COMPLETED", {
          httpStatus: response.status,
          responseCode: result.code,
        });
        notifyConnector(task, "COMPLETED", null, {
          httpStatus: response.status,
          responseCode: result.code,
          sessionCookieFound: true,
          cookieCount: cookies.length,
        });
        await removeTask(task, true);
      } else if (response.status === 400) {
        const result = await readCompletionResult(response);
        logAuthorization(task.platform, "complete", "SESSION_NOT_RECOGNIZED", {
          httpStatus: response.status,
          responseCode: result.code,
        });
        notifyConnector(task, "FAILED", "SESSION_NOT_RECOGNIZED", {
          httpStatus: response.status,
          responseCode: result.code,
          sessionCookieFound: true,
          cookieCount: cookies.length,
        });
        await removeTask(task, false);
      } else if ([401, 409, 410].includes(response.status)) {
        const result = await readCompletionResult(response);
        const errorCode = response.status === 401 ? "HANDOFF_INVALID"
          : response.status === 409 ? "TASK_CONFLICT" : "TASK_EXPIRED";
        logAuthorization(task.platform, "complete", errorCode, {
          httpStatus: response.status,
          responseCode: result.code,
        });
        notifyConnector(task, "FAILED", errorCode, {
          httpStatus: response.status,
          responseCode: result.code,
          sessionCookieFound: true,
          cookieCount: cookies.length,
        });
        await removeTask(task, true);
      } else if (response.status >= 500 || response.status === 429) {
        const result = await readCompletionResult(response);
        logAuthorization(task.platform, "complete", "SERVICE_UNAVAILABLE", {
          httpStatus: response.status,
          responseCode: result.code,
        });
        notifyConnector(task, "RETRYING", "SERVICE_UNAVAILABLE", {
          httpStatus: response.status,
          responseCode: result.code,
          sessionCookieFound: true,
          cookieCount: cookies.length,
        });
      } else {
        const result = await readCompletionResult(response);
        logAuthorization(task.platform, "complete", "SUBMISSION_FAILED", {
          httpStatus: response.status,
          responseCode: result.code,
        });
        notifyConnector(task, "FAILED", "SUBMISSION_FAILED", {
          httpStatus: response.status,
          responseCode: result.code,
          sessionCookieFound: true,
          cookieCount: cookies.length,
        });
        await removeTask(task, false);
      }
    } catch {
      logAuthorization(task.platform, "cookie-check", "COOKIE_ACCESS_FAILED");
      notifyConnector(task, "FAILED", "COOKIE_ACCESS_FAILED");
      await removeTask(task, false);
    } finally {
      inFlightTasks.delete(task.taskId);
    }
  }
}

function notifyConnector(task, state, errorCode, diagnostic) {
  if (!Number.isInteger(task.connectorTabId)) return;
  const message = { type: "AUTHORIZATION_PROGRESS", taskId: task.taskId, state };
  if (errorCode) message.errorCode = errorCode;
  if (diagnostic) message.diagnostic = diagnostic;
  try {
    const pending = chrome.tabs.sendMessage(task.connectorTabId, message);
    if (pending && typeof pending.catch === "function") pending.catch(() => {});
  } catch {
    // The DinQorAI tab may have been closed; never log credentials or handoff tokens.
  }
}

function logAuthorization(platform, phase, result, diagnostic = {}) {
  // Keep browser-console diagnostics useful without ever exposing cookie values or handoff tokens.
  console.info("[DinQor Connector] authorization", { platform, phase, result, ...diagnostic });
}

async function readCompletionResult(response) {
  try {
    const body = await response.clone().json();
    return { code: Number.isInteger(body?.code) ? body.code : null };
  } catch {
    return { code: null };
  }
}

async function removeTask(task, closeTab) {
  const remaining = (await readTasks()).filter((entry) => entry.taskId !== task.taskId);
  await chrome.storage.local.set({ [TASKS_KEY]: remaining });
  if (closeTab && Number.isInteger(task.tabId)) {
    try { await chrome.tabs.remove(task.tabId); } catch { /* tab may already be closed */ }
  }
  if (remaining.length === 0) await chrome.alarms.clear("authorization-check");
}

async function readTasks() {
  const stored = await chrome.storage.local.get(TASKS_KEY);
  return Array.isArray(stored[TASKS_KEY]) ? stored[TASKS_KEY] : [];
}

async function getCsdnCookies() {
  const [rootCookies, editorCookies, articleCookies, imageCookies, activityCookies, downloadTokenCookies, userTokenCookies, userNameCookies] = await Promise.all([
    chrome.cookies.getAll({ url: "https://csdn.net/" }),
    chrome.cookies.getAll({ url: PLATFORM_URLS.csdn }),
    chrome.cookies.getAll({ url: "https://bizapi.csdn.net/blog-console-api/v1/postedit/saveArticle" }),
    chrome.cookies.getAll({ url: "https://bizapi.csdn.net/resource-api/v1/image/external/storage" }),
    chrome.cookies.getAll({ url: "https://bizapi.csdn.net/blog-activity/web/v1/star2025/queryBlogStartJoinStatus" }),
    // This authenticated CSDN endpoint is known to receive UserToken; include its exact cookie path.
    chrome.cookies.getAll({
      url: "https://bizapi.csdn.net/download-console-api/v1/user/sources/getUploadListByUserName",
      name: "UserToken",
    }),
    // CSDN moves UserToken between subdomains; limit the fallback to recognized identity cookies.
    chrome.cookies.getAll({ domain: "csdn.net", name: "UserToken" }),
    chrome.cookies.getAll({ domain: "csdn.net", name: "UserName" }),
  ]);
  const csdnCookies = new Map();
  const scopedCookies = [...rootCookies, ...editorCookies, ...articleCookies, ...imageCookies, ...activityCookies, ...downloadTokenCookies];
  const identityFallbackCookies = [...downloadTokenCookies, ...userTokenCookies, ...userNameCookies];
  for (const cookie of [...scopedCookies, ...identityFallbackCookies]) {
    const identity = [cookie.storeId, cookie.domain, cookie.path, cookie.name].join("\u0000");
    csdnCookies.set(identity, cookie);
  }
  const identityCookies = [...activityCookies, ...articleCookies, ...identityFallbackCookies, ...rootCookies, ...editorCookies];
  const accountName = identityCookies.find((cookie) => cookie.name === "UserName" && cookie.value)?.value ?? null;
  return {
    cookies: [...csdnCookies.values()],
    accountName,
    queryCounts: {
      root: rootCookies.length,
      editor: editorCookies.length,
      article: articleCookies.length,
      image: imageCookies.length,
      activity: activityCookies.length,
      download: downloadTokenCookies.length,
      domain: identityFallbackCookies.length,
    },
  };
}

function platformForCookie(cookie) {
  const domain = cookie.domain.replace(/^\./, "");
  for (const [platform, domains] of Object.entries(PLATFORM_COOKIE_DOMAINS)) {
    if (domains.some((allowed) => domain === allowed || domain.endsWith(`.${allowed}`))) return platform;
  }
  return null;
}
