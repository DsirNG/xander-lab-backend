(() => {
  const channel = "dinqorai-platform-connector";
  const taskIdPattern = /^[0-9a-f-]{36}$/i;
  const supportedPlatforms = [
    "csdn", "juejin", "wechat_mp", "weibo", "zhihu", "baijiahao", "cnblogs",
    "douyin", "xiaohongshu", "toutiao", "51cto", "jianshu", "segmentfault",
    "oschina", "bilibili", "tencent_dev", "aliyun_dev",
  ];
  const allowedOrigins = new Set([
    "https://dinqor.cn",
    "https://xiaod.dpdns.org",
    "http://localhost:5173",
    "http://localhost:3000",
  ]);

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type !== "AUTHORIZATION_PROGRESS" || !taskIdPattern.test(message.taskId)
      || !["WAITING_FOR_SESSION", "SUBMITTING", "RETRYING", "COMPLETED", "FAILED"].includes(message.state)) return false;

    window.postMessage({
      channel,
      type: "AUTHORIZATION_PROGRESS",
      taskId: message.taskId,
      state: message.state,
      errorCode: typeof message.errorCode === "string" ? message.errorCode : null,
    }, window.location.origin);
    return false;
  });

  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== window.location.origin
      || !allowedOrigins.has(event.origin) || event.data?.channel !== channel) return;

    const message = event.data;
    if (message.type === "PING") {
      chrome.runtime.sendMessage({ type: "PING" }, (reply) => {
        window.postMessage({ channel, type: "PONG", requestId: message.requestId, available: Boolean(reply?.available) }, event.origin);
      });
      return;
    }
    if (message.type === "CANCEL" && typeof message.taskId === "string") {
      chrome.runtime.sendMessage({ type: "CANCEL", taskId: message.taskId });
      return;
    }
    if (message.type !== "START" || typeof message.requestId !== "string"
      || !supportedPlatforms.includes(message.platform)
      || typeof message.taskId !== "string" || typeof message.transferToken !== "string") return;

    chrome.runtime.sendMessage({
      type: "START",
      platform: message.platform,
      taskId: message.taskId,
      transferToken: message.transferToken,
    }, (reply) => {
      const runtimeError = chrome.runtime.lastError;
      window.postMessage({
        channel,
        type: "START_RESULT",
        requestId: message.requestId,
        ok: !runtimeError && Boolean(reply?.ok),
      }, event.origin);
    });
  });
})();
