import assert from "node:assert/strict";
import test from "node:test";

const tick = () => new Promise((resolve) => setTimeout(resolve, 0));

async function waitFor(predicate) {
  for (let attempt = 0; attempt < 50; attempt += 1) {
    if (predicate()) return;
    await tick();
  }
  assert.fail("timed out waiting for extension progress");
}

test("reports cookie, permission, and submission progress to the originating DinQor tab", async (context) => {
  const originalConsole = globalThis.console;
  context.after(() => { globalThis.console = originalConsole; });
  const events = new Map();
  const makeEvent = (name) => ({
    addListener(listener) {
      const listeners = events.get(name) || [];
      listeners.push(listener);
      events.set(name, listeners);
    },
  });
  const storage = {};
  const progress = [];
  const closedTabs = [];
  let cookies = [];
  const cookieQueries = [];
  const submittedBodies = [];
  const diagnosticLogs = [];
  let platformPermission = true;
  let completionStatus = 200;
  let nextTabId = 200;
  const chromeApi = {
    runtime: { onMessage: makeEvent("message") },
    cookies: {
      onChanged: makeEvent("cookie"),
      getAll: async (query) => {
        cookieQueries.push(query);
        const queryUrl = query.url ? new URL(query.url) : null;
        return cookies.filter((entry) => {
          const cookieDomain = entry.domain.replace(/^\./, "");
          if (query.name && entry.name !== query.name) return false;
          if (query.domain) {
            return cookieDomain === query.domain || cookieDomain.endsWith(`.${query.domain}`);
          }
          const domainMatches = entry.hostOnly
            ? queryUrl.hostname === cookieDomain
            : queryUrl.hostname === cookieDomain || queryUrl.hostname.endsWith(`.${cookieDomain}`);
          const cookiePath = entry.path || "/";
          const pathMatches = queryUrl.pathname === cookiePath
            || queryUrl.pathname.startsWith(cookiePath.endsWith("/") ? cookiePath : `${cookiePath}/`);
          return domainMatches && pathMatches;
        });
      },
    },
    permissions: { contains: async () => platformPermission },
    tabs: {
      create: async () => ({ id: nextTabId++ }),
      remove: async (tabId) => closedTabs.push(tabId),
      sendMessage: async (tabId, message) => progress.push({ tabId, ...message }),
    },
    storage: {
      local: {
        get: async (key) => ({ [key]: storage[key] }),
        set: async (value) => Object.assign(storage, value),
      },
    },
    alarms: { create() {}, clear: async () => true, onAlarm: makeEvent("alarm") },
  };

  globalThis.chrome = chromeApi;
  globalThis.console = { info: (...values) => diagnosticLogs.push(values) };
  globalThis.fetch = async (_url, options) => {
    submittedBodies.push(JSON.parse(options.body));
    const code = completionStatus;
    return new Response(JSON.stringify({ code, message: code === 200 ? "success" : "invalid session", data: null }), {
      status: completionStatus,
    });
  };
  await import(`../background.js?test=${Date.now()}`);

  const startTask = async (taskId) => {
    const responses = [];
    const listener = events.get("message")[0];
    const keptOpen = listener({
      type: "START", platform: "csdn", taskId, transferToken: "A".repeat(43),
    }, { url: "http://localhost:3000/profile", tab: { id: 55 } }, (value) => responses.push(value));
    assert.equal(keptOpen, true);
    await waitFor(() => responses.length === 1);
    assert.deepEqual(responses[0], { ok: true });
  };

  const taskId = "123e4567-e89b-42d3-a456-426614174000";
  await startTask(taskId);
  await waitFor(() => progress.some((entry) => entry.taskId === taskId && entry.state === "WAITING_FOR_SESSION"));
  assert.ok(progress.some((entry) => entry.taskId === taskId
    && entry.errorCode === "SESSION_COOKIE_MISSING"
    && entry.diagnostic?.sitePermissionGranted === true
    && entry.diagnostic?.sessionCookieFound === false));

  // UserToken can be scoped to a CSDN subdomain that the publishing URL queries do not cover.
  cookies = [
    { name: "UserName", value: "test-user", domain: "csdn.net", hostOnly: true },
    { name: "shared", value: "cookie", domain: ".csdn.net", hostOnly: false, path: "/" },
    { name: "UserToken", value: "test-cookie", domain: "passport.csdn.net", hostOnly: true, path: "/" },
  ];
  for (const listener of events.get("cookie")) {
    listener({ cookie: cookies[2], removed: false });
  }
  await waitFor(() => progress.some((entry) => entry.taskId === taskId && entry.state === "COMPLETED"));
  assert.ok(progress.some((entry) => entry.taskId === taskId && entry.state === "SUBMITTING"));
  const completed = progress.find((entry) => entry.taskId === taskId && entry.state === "COMPLETED");
  assert.equal(completed.diagnostic.httpStatus, 200);
  assert.equal(completed.diagnostic.responseCode, 200);
  assert.ok(cookieQueries.some((query) => query.url === "https://csdn.net/"));
  assert.ok(cookieQueries.some((query) => query.url === "https://mp.csdn.net/"));
  assert.ok(cookieQueries.some((query) => query.url === "https://bizapi.csdn.net/blog-activity/web/v1/star2025/queryBlogStartJoinStatus"));
  assert.ok(cookieQueries.some((query) => query.domain === "csdn.net"));
  const submittedCookies = submittedBodies[0].credential.cookie.split("; ");
  assert.equal(submittedCookies.length, 3);
  assert.deepEqual(new Set(submittedCookies), new Set([
    "UserName=test-user", "UserToken=test-cookie", "shared=cookie",
  ]));
  assert.equal(submittedBodies[0].accountName, "test-user");
  const serializedLogs = JSON.stringify(diagnosticLogs);
  assert.doesNotMatch(serializedLogs, /test-cookie|A{43}|test-user/);
  assert.match(serializedLogs, /SESSION_COOKIE_FOUND/);
  assert.match(serializedLogs, /COMPLETED/);
  assert.deepEqual(storage.authorizationTasks, []);
  assert.deepEqual(closedTabs, [200]);

  completionStatus = 400;
  const rejectedTaskId = "123e4567-e89b-42d3-a456-426614174001";
  await startTask(rejectedTaskId);
  await waitFor(() => progress.some((entry) => entry.taskId === rejectedTaskId && entry.errorCode === "SESSION_NOT_RECOGNIZED"));
  const rejected = progress.find((entry) => entry.taskId === rejectedTaskId && entry.errorCode === "SESSION_NOT_RECOGNIZED");
  assert.equal(rejected.diagnostic.httpStatus, 400);
  assert.equal(rejected.diagnostic.responseCode, 400);
  assert.equal(rejected.diagnostic.sessionCookieFound, true);
  assert.equal(storage.authorizationTasks.length, 0);
  assert.deepEqual(closedTabs, [200]);

  platformPermission = false;
  const permissionTaskId = "123e4567-e89b-42d3-a456-426614174002";
  await startTask(permissionTaskId);
  await waitFor(() => progress.some((entry) => entry.taskId === permissionTaskId && entry.errorCode === "SITE_PERMISSION_REQUIRED"));
  assert.equal(storage.authorizationTasks.length, 0);
});
