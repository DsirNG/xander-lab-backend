import assert from "node:assert/strict";
import test from "node:test";

const tick = () => new Promise((resolve) => setTimeout(resolve, 0));

async function waitFor(predicate) {
  for (let attempt = 0; attempt < 50; attempt += 1) {
    if (predicate()) return;
    await tick();
  }
  assert.fail("timed out waiting for extension progress");
}

test("reports cookie, permission, and submission progress to the originating DinQor tab", async () => {
  const events = new Map();
  const makeEvent = (name) => ({
    addListener(listener) {
      const listeners = events.get(name) || [];
      listeners.push(listener);
      events.set(name, listeners);
    },
  });
  const storage = {};
  const progress = [];
  const closedTabs = [];
  let cookies = [];
  const cookieQueries = [];
  const submittedBodies = [];
  let platformPermission = true;
  let completionStatus = 200;
  let nextTabId = 200;
  const chromeApi = {
    runtime: { onMessage: makeEvent("message") },
    cookies: {
      onChanged: makeEvent("cookie"),
      getAll: async (query) => {
        cookieQueries.push(query);
        const requestUrl = new URL(query.url);
        const hostname = requestUrl.hostname;
        return cookies.filter((entry) => {
          const cookieDomain = entry.domain.replace(/^\./, "");
          const domainMatches = entry.hostOnly
            ? hostname === cookieDomain
            : hostname === cookieDomain || hostname.endsWith(`.${cookieDomain}`);
          const cookiePath = entry.path || "/";
          const pathMatches = cookiePath === "/" || requestUrl.pathname === cookiePath
            || requestUrl.pathname.startsWith(cookiePath.endsWith("/") ? cookiePath : `${cookiePath}/`);
          return domainMatches && pathMatches;
        });
      },
    },
    permissions: { contains: async () => platformPermission },
    tabs: {
      create: async () => ({ id: nextTabId++ }),
      remove: async (tabId) => closedTabs.push(tabId),
      sendMessage: async (tabId, message) => progress.push({ tabId, ...message }),
    },
    storage: {
      local: {
        get: async (key) => ({ [key]: storage[key] }),
        set: async (value) => Object.assign(storage, value),
      },
    },
    alarms: { create() {}, clear: async () => true, onAlarm: makeEvent("alarm") },
  };

  globalThis.chrome = chromeApi;
  globalThis.fetch = async (_url, options) => {
    submittedBodies.push(JSON.parse(options.body));
    return new Response("{}", { status: completionStatus });
  };
  await import(`../background.js?test=${Date.now()}`);

  const startTask = async (taskId) => {
    const responses = [];
    const listener = events.get("message")[0];
    const keptOpen = listener({
      type: "START", platform: "csdn", taskId, transferToken: "A".repeat(43),
    }, { url: "http://localhost:3000/profile", tab: { id: 55 } }, (value) => responses.push(value));
    assert.equal(keptOpen, true);
    await waitFor(() => responses.length === 1);
    assert.deepEqual(responses[0], { ok: true });
  };

  const taskId = "123e4567-e89b-42d3-a456-426614174000";
  await startTask(taskId);
  await waitFor(() => progress.some((entry) => entry.taskId === taskId && entry.state === "WAITING_FOR_SESSION"));

  // The session is scoped to the CSDN API host; account display identity is on the root host.
  cookies = [
    { name: "UserToken", value: "test-cookie", domain: "bizapi.csdn.net", hostOnly: true, path: "/" },
    { name: "UserName", value: "test-user", domain: "csdn.net", hostOnly: true },
    { name: "shared", value: "cookie", domain: ".csdn.net", hostOnly: false, path: "/" },
  ];
  for (const listener of events.get("cookie")) {
    listener({ cookie: cookies[0], removed: false });
  }
  await waitFor(() => progress.some((entry) => entry.taskId === taskId && entry.state === "COMPLETED"));
  assert.ok(progress.some((entry) => entry.taskId === taskId && entry.state === "SUBMITTING"));
  assert.ok(cookieQueries.some((query) => query.url === "https://csdn.net/"));
  assert.ok(cookieQueries.some((query) => query.url === "https://mp.csdn.net/"));
  assert.ok(cookieQueries.some((query) => query.url === "https://bizapi.csdn.net/blog-console-api/v1/postedit/saveArticle"));
  assert.ok(cookieQueries.some((query) => query.url === "https://bizapi.csdn.net/resource-api/v1/image/external/storage"));
  const submittedCookies = submittedBodies[0].credential.cookie.split("; ");
  assert.equal(submittedCookies.length, 2);
  assert.deepEqual(new Set(submittedCookies), new Set([
    "UserToken=test-cookie", "shared=cookie",
  ]));
  assert.equal(submittedBodies[0].accountName, "test-user");
  assert.deepEqual(storage.authorizationTasks, []);
  assert.deepEqual(closedTabs, [200]);

  completionStatus = 400;
  const rejectedTaskId = "123e4567-e89b-42d3-a456-426614174001";
  await startTask(rejectedTaskId);
  await waitFor(() => progress.some((entry) => entry.taskId === rejectedTaskId && entry.errorCode === "SESSION_NOT_RECOGNIZED"));
  assert.equal(storage.authorizationTasks.length, 0);
  assert.deepEqual(closedTabs, [200]);

  platformPermission = false;
  const permissionTaskId = "123e4567-e89b-42d3-a456-426614174002";
  await startTask(permissionTaskId);
  await waitFor(() => progress.some((entry) => entry.taskId === permissionTaskId && entry.errorCode === "SITE_PERMISSION_REQUIRED"));
  assert.equal(storage.authorizationTasks.length, 0);
});
